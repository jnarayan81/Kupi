#Ctreate simulated genome 

path=/home/vikas/Downloads/simuG

#Varaint / Mutant generation
perl $path/simuG.pl \
     -refseq SARS-Cov2_COVID_ref.fasta\
     -indel_count 10 \
     -prefix cov1
     

perl $path/simuG.pl \
     -refseq SARS-Cov2_COVID_ref.fasta\
     -indel_count 20 \
     -prefix cov2
     
     

perl $path/simuG.pl \
     -refseq cov1.simseq.genome.fa\
     -indel_count 10 \
     -prefix cov1.1
     

perl $path/simuG.pl \
     -refseq cov1.simseq.genome.fa\
     -indel_count 20 \
     -prefix cov1.2
     

perl $path/simuG.pl \
     -refseq cov2.simseq.genome.fa\
     -indel_count 10 \
     -prefix cov2.1
     

perl $path/simuG.pl \
     -refseq cov2.simseq.genome.fa\
     -indel_count 20 \
     -prefix cov2.2
     

#Now create two next variant 
#Use cov2.2 to evolve -- here x.x is 2.2
perl $path/simuG.pl \
     -refseq cov2.2.simseq.genome.fa\
     -indel_count 10 \
     -prefix cov2.2.1
     

perl $path/simuG.pl -refseq cov1.2.simseq.genome.fa -snp_count 10 -prefix cov1.2.1


